/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ucsd.ccdb.segmentation.chm.rest;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
/**
 *
 * @author ncmir
 */
@XmlRootElement(name = "CHM_Model")
public class CHM_Model 
{
    private long id = -1;
    private long MPID = -1;
    private String DESCRIPTION = null;
    private String MODEL_NAME = null;

    /**
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    @XmlAttribute
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the MPID
     */
    public long getMPID() {
        return MPID;
    }

    /**
     * @param MPID the MPID to set
     */
    @XmlAttribute
    public void setMPID(long MPID) {
        this.MPID = MPID;
    }

    /**
     * @return the DESCRIPTION
     */
    public String getDESCRIPTION() {
        return DESCRIPTION;
    }

    /**
     * @param DESCRIPTION the DESCRIPTION to set
     */
    @XmlAttribute
    public void setDESCRIPTION(String DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    /**
     * @return the MODEL_NAME
     */
    public String getMODEL_NAME() {
        return MODEL_NAME;
    }

    /**
     * @param MODEL_NAME the MODEL_NAME to set
     */
    @XmlAttribute
    public void setMODEL_NAME(String MODEL_NAME) {
        this.MODEL_NAME = MODEL_NAME;
    }
    
}
