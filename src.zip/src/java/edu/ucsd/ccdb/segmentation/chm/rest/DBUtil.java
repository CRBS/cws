/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.ucsd.ccdb.segmentation.chm.rest;
import java.util.*;
import java.sql.*;
/**
 *
 * @author ncmir
 */
public class DBUtil 
{
    DBService db =new DBService();
    public List<CHM_Model> getAllChmModels()throws Exception
    {
        List<CHM_Model> list = new ArrayList<CHM_Model>();
        String sql = "select id, mpid, description, model_name from slash_chm_model";
        Connection c = db.getConnection();
        PreparedStatement ps = c.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
            CHM_Model model = new CHM_Model();
            long id = rs.getLong("id");
            long mpid = rs.getLong("mpid");
            String desc = rs.getString("description");
            String modelName = rs.getString("model_name");
            model.setId(id);
            model.setMPID(mpid);
            model.setDESCRIPTION(desc);
            model.setMODEL_NAME(modelName);
            list.add(model);
            
        }
        c.close();
        return list;
    }
    
    public CHM_Model getChmModel(long id) throws Exception
    {
        
        String sql = "select id, mpid, description, model_name from slash_chm_model where id = ?";
        Connection c = db.getConnection();
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setLong(1, id);
        ResultSet rs = ps.executeQuery();
        CHM_Model model = null;
        if(rs.next())
        {
            
            
            model = new CHM_Model();
            long mpid = rs.getLong("mpid");
            String desc = rs.getString("description");
            String modelName = rs.getString("model_name");
            model.setId(id);
            model.setMPID(mpid);
            model.setDESCRIPTION(desc);
            model.setMODEL_NAME(modelName);
        }
        c.close();
        return model;
        
    }
    
    
    public static void main(String[] args)throws Exception
    {
        DBUtil dbutil = new DBUtil();
        /*List<CHM_Model> list = dbutil.getAllChmModels();
        for(int i=0;i<list.size();i++)
        {
            CHM_Model model = list.get(i);
            System.out.println(model);
        }*/
        CHM_Model model = dbutil.getChmModel(5235515);
        System.out.println(model);
    }
}
